astyle --style=ansi -s4 --recursive ./*.cpp ./*.h ./*.hpp
